print("sunny")
